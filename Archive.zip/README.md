# Spec
---

## General
---
Well documented

## HTML Style
---
Semantic/descriptive id/class naming scheme

## CSS Style
---
SCSS
REM w/ px fallback for sizing

## Performance
---
Use ID's first & classes if I have to
Minified CSS & JS
Minimize request
Remove unused css
Set header expires on server

## HTML Boilerplate
---
HTML5 Boilerplate

## CSS Framework/Libraries
---
Bootstrap 


## JS 
---

### Build Tools
Gulp
[slush-webapp](https://github.com/jonkemp/slush-webapp "slush-webapp")

### Framework/Libraries
jQuery
jQuery UI
Modernizr

### Scripts/Plugins
fullPage.js
Lettering.js
Textillate.js
[Runloop.js](https://github.com/KuraFire/runloop "Runloop.js")
[InstantClick](http://instantclick.io/ "InstantClick")
